#Variables
a = 5.56
b = 5.56

#Initial statement
print((not (a < b) and not (a > b)))

#Simplified statement
print(a == b)
