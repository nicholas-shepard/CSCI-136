import math

print((math.sqrt(2) * math.sqrt(2) == 2))
#Evaluates to false because some precision is lost by the sqrt function
