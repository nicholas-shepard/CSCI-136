import math

#Coordinates
x = 4
y = 3

#Pythagorean theorem
distance = math.sqrt(x ** 2 + y ** 2)
print(distance)
