import sys

userNum = int(sys.argv[1])

twos = 2

while twos <= userNum:
    print(twos)
    twos *= 2
